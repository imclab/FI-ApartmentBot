Serial Proxy Instructions:
The file "serproxy" is the Mac executable. "serproxy.exe" is the Windows executable.

The serial proxy application reads its configuration from serproxy.cfg. Separate example configuration files for Windows and Mac are supplied (serproxy.cfg.win and serproxy.cfg.mac). Open the appropriate file for your platform, adjust settings to reflect your serial port configuration, then save as serproxy.cfg.

The default Firmata2 serial speed is 115200.
